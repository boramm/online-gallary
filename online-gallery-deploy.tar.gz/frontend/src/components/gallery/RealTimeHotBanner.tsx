"use client";

import { motion } from "framer-motion";
import { Heart, Eye, ArrowRight, Flame } from "lucide-react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectCoverflow } from "swiper/modules";
import "swiper/css";
import "swiper/css/effect-coverflow";

interface Photo {
  id: string;
  title: string;
  imageUrl: string;
  thumbnailUrl?: string;
  departmentName: string;
  likeCount: number;
  viewCount: number;
}

interface RealTimeHotBannerProps {
  photos: Photo[];
}

const RANK_CONFIG = [
  {
    rank: "TOP 1",
    emoji: "🔥",
    gradient: "from-red-500 via-orange-500 to-yellow-500",
    glow: "shadow-red-500/50",
    size: "large",
  },
  {
    rank: "TOP 2",
    emoji: "❤️",
    gradient: "from-pink-500 via-rose-500 to-red-500",
    glow: "shadow-pink-500/50",
    size: "medium",
  },
  {
    rank: "TOP 3",
    emoji: "⭐",
    gradient: "from-blue-500 via-purple-500 to-pink-500",
    glow: "shadow-purple-500/50",
    size: "medium",
  },
];

export default function RealTimeHotBanner({ photos }: RealTimeHotBannerProps) {
  const topThree = photos.slice(0, 3);

  if (topThree.length === 0) return null;

  const currentTime = new Date().toLocaleTimeString("ko-KR", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <section className="relative py-12 px-4 overflow-hidden">
      {/* 배경 그라데이션 */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-pink-900/20 to-red-900/20 dark:from-purple-950/40 dark:via-pink-950/40 dark:to-red-950/40" />

      {/* 별 반짝임 애니메이션 */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="container mx-auto max-w-6xl relative z-10">
        {/* 헤더 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-2">
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 10, -10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            >
              <Flame className="w-8 h-8 text-orange-500" />
            </motion.div>
            <h2 className="text-3xl md:text-4xl font-bold text-gradient">
              실시간 HOT 3
            </h2>
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, -10, 10, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: 0.3,
              }}
            >
              <Flame className="w-8 h-8 text-orange-500" />
            </motion.div>
          </div>
          <p className="text-muted-foreground">지금 가장 인기있는 사진</p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-xs text-muted-foreground mt-2"
          >
            {currentTime} 기준 좋아요 순
          </motion.p>
        </motion.div>

        {/* Swiper */}
        <Swiper
          modules={[Autoplay, EffectCoverflow]}
          effect="coverflow"
          grabCursor={true}
          centeredSlides={true}
          slidesPerView="auto"
          coverflowEffect={{
            rotate: 50,
            stretch: 0,
            depth: 100,
            modifier: 1,
            slideShadows: true,
          }}
          autoplay={{
            delay: 5000,
            disableOnInteraction: false,
          }}
          loop={topThree.length > 1}
          className="!pb-12"
        >
          {topThree.map((photo, index) => {
            const config = RANK_CONFIG[index];
            const isTopOne = index === 0;

            return (
              <SwiperSlide
                key={photo.id}
                className={`!w-[${isTopOne ? "600px" : "500px"}] md:!w-[${
                  isTopOne ? "700px" : "600px"
                }]`}
                style={{
                  width: isTopOne ? "600px" : "500px",
                }}
              >
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative group"
                >
                  {/* 카드 */}
                  <div
                    className={`
                    relative rounded-3xl overflow-hidden glass backdrop-blur-xl 
                    shadow-2xl ${config.glow} transition-all duration-300
                    ${isTopOne ? "h-[400px]" : "h-[350px]"}
                  `}
                  >
                    {/* 이미지 */}
                    <img
                      src={photo.thumbnailUrl || photo.imageUrl}
                      alt={photo.title}
                      className="w-full h-full object-cover"
                    />

                    {/* 그라데이션 오버레이 */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

                    {/* TOP 배지 - 우측 상단 */}
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{
                        type: "spring",
                        stiffness: 200,
                        delay: 0.3 + index * 0.1,
                      }}
                      className={`
                        absolute top-6 right-6 px-6 py-3 rounded-2xl
                        bg-gradient-to-r ${config.gradient}
                        shadow-2xl ${config.glow}
                        flex items-center gap-2
                      `}
                    >
                      <span className="text-3xl">{config.emoji}</span>
                      <span className="text-white font-bold text-xl">
                        {config.rank}
                      </span>
                    </motion.div>

                    {/* 빛나는 효과 (TOP 1만) */}
                    {isTopOne && (
                      <motion.div
                        className="absolute inset-0 pointer-events-none"
                        animate={{
                          background: [
                            "radial-gradient(circle at 50% 50%, rgba(255, 200, 0, 0.3) 0%, transparent 50%)",
                            "radial-gradient(circle at 50% 50%, rgba(255, 100, 0, 0.3) 0%, transparent 50%)",
                            "radial-gradient(circle at 50% 50%, rgba(255, 200, 0, 0.3) 0%, transparent 50%)",
                          ],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                        }}
                      />
                    )}

                    {/* 정보 */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 space-y-3">
                      {/* 부서명 */}
                      <motion.span
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.4 + index * 0.1 }}
                        className={`
                          inline-block px-4 py-1.5 rounded-full text-white text-sm font-medium
                          bg-gradient-to-r ${config.gradient}
                        `}
                      >
                        {photo.departmentName}
                      </motion.span>

                      {/* 제목 */}
                      <motion.h3
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.5 + index * 0.1 }}
                        className={`text-white font-bold line-clamp-2 ${
                          isTopOne ? "text-3xl" : "text-2xl"
                        }`}
                      >
                        {photo.title}
                      </motion.h3>

                      {/* 통계 + 버튼 */}
                      <motion.div
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.6 + index * 0.1 }}
                        className="flex items-center justify-between"
                      >
                        {/* 통계 */}
                        <div className="flex gap-4 text-white">
                          <div className="flex items-center gap-2">
                            <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                            <span className="text-lg font-bold">
                              {photo.likeCount.toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Eye className="w-5 h-5" />
                            <span className="text-lg font-bold">
                              {photo.viewCount.toLocaleString()}
                            </span>
                          </div>
                        </div>

                        {/* 자세히 보기 버튼 */}
                        <motion.button
                          whileHover={{ scale: 1.05, x: 5 }}
                          whileTap={{ scale: 0.95 }}
                          className={`
                            flex items-center gap-2 px-4 py-2 rounded-lg
                            bg-white/20 backdrop-blur-sm hover:bg-white/30
                            text-white font-semibold transition-all
                          `}
                        >
                          <span>자세히</span>
                          <ArrowRight className="w-4 h-4" />
                        </motion.button>
                      </motion.div>
                    </div>

                    {/* 호버 글로우 */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileHover={{ opacity: 0.5 }}
                      transition={{ duration: 0.3 }}
                      className={`
                        absolute inset-0 pointer-events-none
                        bg-gradient-to-r ${config.gradient}
                        mix-blend-overlay
                      `}
                    />
                  </div>

                  {/* 외부 글로우 효과 */}
                  <motion.div
                    animate={
                      isTopOne
                        ? {
                            opacity: [0.3, 0.6, 0.3],
                            scale: [1, 1.05, 1],
                          }
                        : {}
                    }
                    transition={
                      isTopOne
                        ? {
                            duration: 2,
                            repeat: Infinity,
                          }
                        : {}
                    }
                    className={`
                      absolute inset-0 rounded-3xl blur-2xl -z-10
                      bg-gradient-to-r ${config.gradient}
                      ${config.glow}
                    `}
                  />
                </motion.div>
              </SwiperSlide>
            );
          })}
        </Swiper>

        {/* 하단 안내 문구 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-center mt-8 text-sm text-muted-foreground"
        >
          <p>실시간으로 업데이트되는 인기 순위입니다</p>
        </motion.div>
      </div>
    </section>
  );
}

